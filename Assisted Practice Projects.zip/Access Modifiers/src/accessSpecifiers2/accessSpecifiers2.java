package accessSpecifiers2;
class privateccessspecifier 
{ 
   private void display() 
    { 
        System.out.println("You are using private access specifier"); 
    } 
} 

public class accessSpecifiers2 {

	public static void main(String[] args) {
		//private
		System.out.println("Private Access Specifier");
		privateccessspecifier  obj = new privateccessspecifier(); 
        //trying to access private method of another class 
        //obj.display();

	}
}
