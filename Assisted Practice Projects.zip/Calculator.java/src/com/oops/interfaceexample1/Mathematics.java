package com.oops.interfaceexample1;

public interface Mathematics {
	int addition(int num1, int num2);
	int subraction(int num1, int num2);
	int multiplication(int num1,int num2);
	int division(int num1, int num2);

}
