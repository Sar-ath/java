package Files;


	import java.io.FileWriter;
	import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;
import java.io.File;
import java.io.FileInputStream;
	import java.io.IOException;
	import java.util.Scanner;

	public class Writerfile {
		public static void main(String[] args) throws IOException {
			File file =new File("input");
			FileWriter fw = new FileWriter(file,true);
			PrintWriter pw =  new PrintWriter(fw);
			
			pw.print("sarath");
			pw.print("hello");
			pw.print("how are you");
			pw.close();
	}
	}


